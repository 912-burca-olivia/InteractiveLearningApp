export const environment = {
    production: false,
    serviceUrl: 'http://localhost:8080/filemanager/'
  };
  